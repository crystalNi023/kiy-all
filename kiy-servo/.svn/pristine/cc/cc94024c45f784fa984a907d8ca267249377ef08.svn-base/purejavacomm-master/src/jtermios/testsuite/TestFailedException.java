package jtermios.testsuite;

@SuppressWarnings("serial") class TestFailedException extends Exception {
}