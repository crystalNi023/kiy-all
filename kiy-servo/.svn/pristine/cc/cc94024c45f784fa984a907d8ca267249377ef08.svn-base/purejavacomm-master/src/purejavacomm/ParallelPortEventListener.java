package purejavacomm;

public interface ParallelPortEventListener {
	 void parallelEvent(ParallelPortEvent ev);
}
