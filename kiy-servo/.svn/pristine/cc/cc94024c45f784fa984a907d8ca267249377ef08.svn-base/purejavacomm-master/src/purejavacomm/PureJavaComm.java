package purejavacomm;

public class PureJavaComm {
	// change this if you modify the code and re-distribute
	public static String getVersion() {
		return "1.0.1";
	}

	// change this is if you fork the project
	public static String getFork() {
		return "SpareTimeLabs";
	}

}
